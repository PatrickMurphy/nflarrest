<?php
session_start();
require_once('googleMeasurementProtocol.php');
if(!array_key_exists('UUIDCID', $_SESSION)){
    $_SESSION['UUIDCID'] = gaGenUUID();
}
require_once('PHP-Multi-SQL/classes/MySQL.class.php');

require_once('db_config.php');

$db = new MySQL($db_info['host'], $db_info['user'], $db_info['password'], $db_info['db_name']);

if($db == false){
	die('DB connection error.');
}

function gather_results($result){
	$return_array = [];
	for($i = 0; $i < $result->num_rows; $i++){
		$return_array[] = $result->fetch_assoc();
	}
	return $return_array;
}
 header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header( "Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS" );
 header('Content-type:application/json');

//sets the table that standard queries pull from
$DB_MAIN_TABLE = 'ArrestsCacheTable';

$el = "Default";
if(isset($_GET['id'])){
	$el = $_GET['id'];
}
$ea = $_SERVER["SCRIPT_FILENAME"];
if(basename($_SERVER["SCRIPT_FILENAME"]) == 'router.php'){
	$ea = $endpoint . ' ' . $verb;
}
    //  'cid'=>$_SESSION['UUIDCID'],
$param = array (
      'v'=>1,
      'tid'=>'UA-101771726-1',
      'uip' =>  GetClientIP(TRUE),
      'ua' => $_SERVER['HTTP_USER_AGENT'],
      't'=>'event',
      'ec'=>"NFL Arrest API",
      'ea'=> $ea,
      'el'=> $el,
      'ev'=> 1, // number of rows?
      'ds' => 'API',
      'cd1'=> "DateStart",
      'cd2'=> "DateEnd",
      'cd3'=> "Limit"
    );
    
    
sendGAHit($param);