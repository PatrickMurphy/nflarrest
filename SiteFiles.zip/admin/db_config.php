<?php
$db_info['host'] = '192.185.35.74';
$db_info['user'] = 'pmphotog_nfladmn';
$db_info['password'] = 'DopeBeatYeah?2018';
$db_info['db_name'] = 'pmphotog_nfl';