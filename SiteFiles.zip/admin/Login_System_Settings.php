<?php
$login_system_settings['form_elements'] = array();
$login_system_settings['form_elements']['username'] = 'username';
$login_system_settings['form_elements']['password'] = 'password';

$login_system_settings['values'] = array();
$login_system_settings['values']['auth_code'] = 1137;
$login_system_settings['values']['username'] = 'patrickmurphoto';
$login_system_settings['values']['password'] = 'DeepSnow2017';

$login_system_settings['errors'] = array();
$login_system_settings['errors']['invalid_login'] = '<div style="border:#ff4f4f; background:#ffa5a5;"><b>Error:</b> Incorrect login Details.</div>';
?>
