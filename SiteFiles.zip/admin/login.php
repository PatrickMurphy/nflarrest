<div style="border-radius:6px; box-shadow: 0px 2px 2px #bbb" class="six columns offset-by-three">
<h2>Login</h2>
<form action="admin/index.php" method="POST">
<label style="width:95%;text-align:left;margin-left:2%;">Username: </label>
<input style="width:95%;margin-bottom:10px;" type="text" name="username" />
<br />
<label style="width:95%;text-align:left;margin-left:2%;">Password: </label>
<input style="width:95%" type="password" name="password" />
<br />
<input style="margin-top:10px;"type="submit" value="Login" />
</form>
</div>