<?php
$db_info['host'] = '192.185.35.74';
$db_info['user'] = 'pmphotog_nfl';
$db_info['password'] = '12thman';
$db_info['db_name'] = 'pmphotog_nfl';